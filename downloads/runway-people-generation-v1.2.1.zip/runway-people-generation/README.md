# runway-people-generation (v1.2.1)

A free Claude skill by Timmy Moser (timmymoser.com).

## Install

**Claude app (web or desktop):** Customize > Skills > Add > Upload a skill, then pick `runway-people-generation-v1.2.1.zip`. Needs a paid plan with Settings > Capabilities > Create and edit files turned on.

**Claude Code:** unzip into `~/.claude/skills/` so you end up with `~/.claude/skills/runway-people-generation/SKILL.md`.

**Updating:** download the newer zip and upload it again. It replaces the old version.

Upload the zip as it is. Don't unzip and re-zip it inside another folder, or the uploader will reject it.
